import { createClient } from "https://esm.sh/@supabase/supabase-js@2.119.2";

(() => {
  "use strict";
  const cfg = window.SENSUAMIX_CONFIG || {};
  const ready = Boolean(cfg.supabaseUrl && cfg.publishableKey);
  const sb = ready ? createClient(cfg.supabaseUrl, cfg.publishableKey, {
    auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
  }) : null;
  const $ = (s, root=document) => root.querySelector(s);
  const esc = (v="") => String(v).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const fmtDate = v => v ? new Intl.DateTimeFormat("pt-BR",{dateStyle:"medium"}).format(new Date(v)) : "—";
  const money = (v,c="USD") => v == null ? "A confirmar" : new Intl.NumberFormat("pt-BR",{style:"currency",currency:c}).format(Number(v));
  const slug = s => s.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().trim().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"");
  const admin = u => u?.app_metadata?.role === "sensuamix_admin";
  const labels = {
    awaiting_supplier_confirmation:"Aguardando fornecedor",quote_ready:"Cotação disponível",
    awaiting_customer_approval:"Aguardando aprovação",awaiting_payment:"Aguardando pagamento",
    paid:"Pago",supplier_processing:"Em preparação pelo parceiro",dispatched:"Despachado",
    delivered:"Entregue",cancelled:"Cancelado",expired:"Expirado",refunded:"Reembolsado"
  };
  let session=null, authMode="login", adminTab="overview", data={}, editingId=null;

  document.body.insertAdjacentHTML("beforeend", `
    <div class="sx-modal sx-hidden" id="sxAuth" role="dialog" aria-modal="true" aria-labelledby="sxAuthTitle">
      <div class="sx-dialog sx-auth"><button class="sx-close" data-sx-close type="button" aria-label="Fechar">×</button>
        <div class="sx-eyebrow">Área reservada do cliente</div><h2 id="sxAuthTitle">Bem-vinda à SensuaMix</h2>
        <p class="sx-muted">Entre na sua conta ou crie seu cadastro para acompanhar seus pedidos.</p>
        <div class="sx-tabs"><button type="button" data-mode="login" class="is-active">Entrar</button><button type="button" data-mode="register">Criar conta</button></div>
        <form id="sxAuthForm" class="sx-form">
          <label id="sxNameWrap" class="sx-hidden">Nome completo<input name="full_name" autocomplete="name" minlength="2"></label>
          <label>E-mail<input name="email" type="email" autocomplete="email" required></label>
          <label id="sxPhoneWrap" class="sx-hidden">Telefone / WhatsApp<input name="phone" type="tel" autocomplete="tel"></label>
          <label>Senha<input name="password" type="password" autocomplete="current-password" minlength="8" required></label>
          <button class="btn primary" id="sxAuthSubmit" type="submit">Entrar</button>
          <button class="sx-text" id="sxForgot" type="button">Esqueci minha senha</button>
          <p class="sx-feedback" id="sxAuthMsg" role="status" aria-live="polite"></p>
        </form><p class="sx-footnote">Seus dados são protegidos pelas permissões de acesso do Supabase. Nenhum cartão é solicitado nesta etapa.</p>
      </div>
    </div>
    <div class="sx-modal sx-hidden" id="sxPanel" role="dialog" aria-modal="true" aria-labelledby="sxPanelTitle">
      <section class="sx-dialog sx-panel"><header class="sx-panel-head"><div><div class="sx-eyebrow">Espaço seguro</div><h2 id="sxPanelTitle">Minha conta</h2><p class="sx-muted" id="sxPanelSub"></p></div><button class="sx-close" type="button" data-sx-close aria-label="Fechar">×</button></header>
      <div id="sxPanelBody" class="sx-panel-body"><p class="sx-loading">Carregando...</p></div></section>
    </div>`);

  const auth = $("#sxAuth"), panel=$("#sxPanel"), form=$("#sxAuthForm"), authMsg=$("#sxAuthMsg");
  const accountButton=$("#accountOpen");

  function message(text, error=false) {
    authMsg.textContent=text; authMsg.classList.toggle("is-error",error);
  }
  function setMode(mode) {
    authMode=mode;
    const reg=mode==="register";
    $("#sxAuthTitle").textContent=reg?"Crie sua conta":"Bem-vinda à SensuaMix";
    $("#sxNameWrap").classList.toggle("sx-hidden",!reg);
    $("#sxPhoneWrap").classList.toggle("sx-hidden",!reg);
    $("#sxForgot").classList.toggle("sx-hidden",reg);
    $("#sxAuthSubmit").textContent=reg?"Criar minha conta":"Entrar";
    form.elements.password.autocomplete=reg?"new-password":"current-password";
    auth.querySelectorAll("[data-mode]").forEach(b=>b.classList.toggle("is-active",b.dataset.mode===mode));
    message("");
  }
  function closeAll(){auth.classList.add("sx-hidden");panel.classList.add("sx-hidden");}
  function updateButton(){if(accountButton) accountButton.textContent=session?.user?"Minha conta":"Entrar / Criar conta";}
  async function syncSession(){
    if(!sb)return;
    const {data:d}=await sb.auth.getSession(); session=d.session; updateButton();
  }
  function openAuth(){
    if(!ready){window.alert("A conexão do Supabase ainda não foi incluída nesta versão.");return;}
    auth.classList.remove("sx-hidden");setMode("login");
  }
  accountButton?.addEventListener("click",async()=>{
    await syncSession();
    if(session?.user) await openPanel(); else openAuth();
  });
  document.addEventListener("click",e=>{
    if(e.target.closest("[data-sx-close]")) closeAll();
    const mode=e.target.closest("[data-mode]"); if(mode)setMode(mode.dataset.mode);
    const tab=e.target.closest("[data-admin-tab]"); if(tab){adminTab=tab.dataset.adminTab;renderAdminTab();}
    const action=e.target.closest("[data-action]"); if(action) handleAction(action.dataset.action,action.dataset.id||"");
  });
  [auth,panel].forEach(el=>el.addEventListener("click",e=>{if(e.target===el)el.classList.add("sx-hidden");}));

  form.addEventListener("submit",async e=>{
    e.preventDefault(); if(!sb)return;
    const fd=new FormData(form), email=String(fd.get("email")||"").trim().toLowerCase(), password=String(fd.get("password")||"");
    const submit=$("#sxAuthSubmit"); submit.disabled=true;message("Processando...");
    try{
      if(authMode==="register"){
        const name=String(fd.get("full_name")||"").trim();
        if(name.length<2)throw new Error("Informe seu nome completo.");
        if(password.length<8)throw new Error("Use uma senha com pelo menos 8 caracteres.");
        const {data:d,error}=await sb.auth.signUp({email,password,options:{data:{full_name:name},emailRedirectTo:location.origin+"/"}});
        if(error)throw error;
        if(d.session){
          const phone=String(fd.get("phone")||"").trim();
          if(phone)await sb.from("customer_profiles").update({phone}).eq("id",d.user.id);
          session=d.session;closeAll();await openPanel();
        }else message("Cadastro iniciado. Confirme seu e-mail pelo link enviado e depois entre na SensuaMix.");
      }else{
        const {data:d,error}=await sb.auth.signInWithPassword({email,password});
        if(error)throw error;session=d.session;closeAll();await openPanel();
      }
    }catch(err){message(err.message||"Não foi possível concluir. Tente novamente.",true);}
    finally{submit.disabled=false;}
  });
  $("#sxForgot").addEventListener("click",async()=>{
    const email=String(form.elements.email.value||"").trim().toLowerCase();
    if(!email)return message("Informe seu e-mail para receber o link de recuperação.",true);
    const {error}=await sb.auth.resetPasswordForEmail(email,{redirectTo:location.origin+"/"});
    message(error?error.message:"Se o endereço estiver cadastrado, enviaremos instruções de recuperação.",Boolean(error));
  });

  async function openPanel(){
    if(!sb)return; await syncSession(); if(!session?.user)return openAuth();
    panel.classList.remove("sx-hidden"); $("#sxPanelTitle").textContent=admin(session.user)?"Painel administrativo":"Minha conta";
    $("#sxPanelSub").textContent=session.user.email||"";$("#sxPanelBody").innerHTML='<p class="sx-loading">Carregando...</p>';
    if(admin(session.user)){adminTab="overview";await loadAdmin();renderAdminShell();}
    else await renderCustomer();
  }
  function panelError(err,retry){
    $("#sxPanelBody").innerHTML=`<div class="sx-error"><strong>Não foi possível carregar esta área.</strong><p>${esc(err.message||"Confira sua conexão e permissões.")}</p><button class="btn" id="sxRetry">Tentar novamente</button></div>`;
    $("#sxRetry")?.addEventListener("click",retry);
  }
  async function renderCustomer(){
    const uid=session.user.id;
    const [p,o]=await Promise.all([
      sb.from("customer_profiles").select("id,full_name,email,phone,created_at").eq("id",uid).maybeSingle(),
      sb.from("orders").select("id,order_code,status,currency_code,order_total,created_at").eq("customer_id",uid).order("created_at",{ascending:false})
    ]);
    if(p.error)return panelError(p.error,renderCustomer);
    if(o.error)return panelError(o.error,renderCustomer);
    const profile=p.data||{full_name:session.user.user_metadata?.full_name||"",email:session.user.email||"",phone:""};
    const orders=o.data||[];
    $("#sxPanelTitle").textContent="Minha conta";
    $("#sxPanelBody").innerHTML=`
      <div class="sx-customer-grid">
        <section class="sx-card"><div class="sx-card-head"><h3>Meus dados</h3><span class="sx-chip">Conta ativa</span></div>
          <form id="sxProfile" class="sx-form one-col">
            <label>Nome completo<input name="full_name" required minlength="2" value="${esc(profile.full_name||"")}"></label>
            <label>E-mail<input value="${esc(profile.email||session.user.email||"")}" disabled></label>
            <label>Telefone / WhatsApp<input name="phone" type="tel" value="${esc(profile.phone||"")}"></label>
            <button class="btn primary" type="submit">Salvar meus dados</button><p class="sx-feedback" id="sxProfileMsg" role="status"></p>
          </form>
        </section>
        <section class="sx-card"><div class="sx-card-head"><h3>Meus pedidos</h3><span class="sx-chip">${orders.length} registro(s)</span></div>
          ${orders.length?`<div class="sx-order-list">${orders.map(o=>`<article class="sx-order"><div><strong>${esc(o.order_code)}</strong><small>${fmtDate(o.created_at)}</small></div><div class="sx-order-right"><span class="sx-status">${esc(labels[o.status]||o.status)}</span><b>${money(o.order_total,o.currency_code||"USD")}</b></div></article>`).join("")}</div>`:'<div class="sx-empty"><strong>Nenhum pedido por aqui ainda.</strong><p>Quando uma solicitação for confirmada com o fornecedor e convertida em pedido, o acompanhamento aparecerá nesta área.</p></div>'}
        </section>
      </div>
      <div class="sx-note"><strong>Pronta entrega por parceiros</strong><p>A SensuaMix não mantém estoque próprio. Antes de qualquer cobrança, confirmamos disponibilidade, preço, frete e prazo com o fornecedor parceiro. Esta área não realiza pagamentos.</p></div>
      <div class="sx-actions"><button class="btn" id="sxReset">Redefinir senha</button><button class="btn" id="sxLogout">Sair da conta</button></div>`;
    $("#sxProfile").addEventListener("submit",async e=>{
      e.preventDefault();const fd=new FormData(e.currentTarget);
      const {error}=await sb.from("customer_profiles").update({full_name:String(fd.get("full_name")).trim(),phone:String(fd.get("phone")||"").trim()||null,updated_at:new Date().toISOString()}).eq("id",uid);
      const msg=$("#sxProfileMsg");msg.textContent=error?error.message:"Seus dados foram atualizados.";msg.classList.toggle("is-error",Boolean(error));
    });
    $("#sxReset").addEventListener("click",async()=>{const {error}=await sb.auth.resetPasswordForEmail(session.user.email,{redirectTo:location.origin+"/"});window.alert(error?error.message:"Enviamos as instruções para seu e-mail, caso ele esteja habilitado.");});
    $("#sxLogout").addEventListener("click",logout);
  }
  async function logout(){
    const {error}=await sb.auth.signOut();if(error)return window.alert(error.message);
    session=null;updateButton();closeAll();
  }

  async function loadAdmin(){
    const specs=[
      ["customers","customer_profiles","id,full_name,email,phone,created_at"],
      ["products","products","id,slug,name,category,short_description,description,image_url,is_published,created_at"],
      ["suppliers","suppliers","id,trade_name,contact_name,contact_email,contact_phone,status,ships_direct_to_customer,discreet_outer_packaging"],
      ["offers","supplier_offers","id,supplier_id,product_id,availability_status,customer_price,currency_code,ready_to_ship,direct_fulfillment_available,checked_at,valid_until,is_active"],
      ["orders","orders","id,order_code,customer_id,status,customer_name,customer_email,customer_phone,currency_code,order_total,created_at"]
    ];
    const results=await Promise.all(specs.map(([key,table,cols])=>sb.from(table).select(cols).order("created_at",{ascending:false}).limit(250)));
    data={};let errors=[];
    results.forEach((r,i)=>{data[specs[i][0]]=r.data||[];if(r.error)errors.push(`${specs[i][0]}: ${r.error.message}`);});
    data.errors=errors;
  }
  function renderAdminShell(){
    $("#sxPanelTitle").textContent="Painel administrativo";
    $("#sxPanelBody").innerHTML=`
      <div class="sx-admin-layout">
        <nav class="sx-admin-nav" aria-label="Navegação administrativa">
          ${[["overview","Visão geral"],["products","Produtos"],["suppliers","Fornecedores"],["offers","Ofertas"],["orders","Pedidos"],["customers","Clientes"]].map(([k,l])=>`<button type="button" data-admin-tab="${k}" class="${adminTab===k?"is-active":""}">${l}</button>`).join("")}
        </nav><div class="sx-admin-main" id="sxAdminMain"></div>
      </div>
      ${data.errors?.length?`<p class="sx-warning">Alguns dados não carregaram: ${esc(data.errors.join(" · "))}. Confira as permissões e tente atualizar.</p>`:""}
      <div class="sx-actions"><button class="btn" id="sxRefresh">Atualizar dados</button><button class="btn" id="sxLogout">Sair da conta</button></div>`;
    $("#sxRefresh").addEventListener("click",async()=>{await loadAdmin();renderAdminShell();});
    $("#sxLogout").addEventListener("click",logout);renderAdminTab();
  }
  function adminOverview(){
    const waiting=(data.orders||[]).filter(o=>["awaiting_supplier_confirmation","quote_ready","awaiting_customer_approval","awaiting_payment"].includes(o.status)).length;
    return `<div class="sx-heading"><div class="sx-eyebrow">Resumo da operação</div><h3>Visão geral</h3></div>
      <div class="sx-stats">${[["Clientes",data.customers?.length||0],["Produtos",data.products?.length||0],["Fornecedores",data.suppliers?.length||0],["Ofertas",data.offers?.length||0],["Pedidos",data.orders?.length||0],["Pendências",waiting]].map(([l,v])=>`<article class="sx-stat"><span>${l}</span><strong>${v}</strong></article>`).join("")}</div>
      <div class="sx-note"><strong>Operação sem estoque próprio</strong><p>A oferta só deve ser apresentada como pronta entrega após confirmação recente do fornecedor e dentro da validade registrada. O painel não cria cobranças nem processa pagamentos.</p></div>`;
  }
  function renderProducts(){
    const current=(data.products||[]).find(p=>p.id===editingId);
    return `<div class="sx-heading"><div class="sx-eyebrow">Catálogo público</div><h3>Produtos</h3></div>
      <form class="sx-form sx-admin-form" data-form="product">
        <input type="hidden" name="id" value="${esc(current?.id||"")}">
        <label>Nome<input name="name" required value="${esc(current?.name||"")}"></label>
        <label>Categoria<select name="category"><option value="lingerie" ${current?.category==="lingerie"?"selected":""}>Lingerie</option><option value="bem-estar" ${current?.category==="bem-estar"?"selected":""}>Bem-estar íntimo</option></select></label>
        <label>Descrição curta<input name="short_description" value="${esc(current?.short_description||"")}"></label>
        <label>Imagem (URL)<input name="image_url" type="url" value="${esc(current?.image_url||"")}"></label>
        <label class="sx-full">Descrição<textarea name="description" rows="3">${esc(current?.description||"")}</textarea></label>
        <label class="sx-check"><input name="is_published" type="checkbox" ${current?.is_published?"checked":""}> Publicar no catálogo</label>
        <div class="sx-full sx-form-actions"><button class="btn primary" type="submit">${current?"Salvar alterações":"Cadastrar produto"}</button>${current?'<button class="btn" type="button" data-action="cancel-edit">Cancelar</button>':""}</div>
      </form>
      ${table(["Produto","Categoria","Catálogo",""],(data.products||[]).map(p=>[`<strong>${esc(p.name)}</strong><small>${esc(p.slug)}</small>`,esc(p.category),p.is_published?"Publicado":"Rascunho",`<button class="sx-mini" type="button" data-action="edit-product" data-id="${esc(p.id)}">Editar</button>`]))}`;
  }
  function renderSuppliers(){
    return `<div class="sx-heading"><div class="sx-eyebrow">Parceiros de despacho</div><h3>Fornecedores</h3></div>
      <form class="sx-form sx-admin-form" data-form="supplier">
        <label>Nome comercial<input name="trade_name" required></label><label>Contato responsável<input name="contact_name"></label>
        <label>E-mail de contato<input name="contact_email" type="email"></label><label>Telefone / WhatsApp<input name="contact_phone"></label>
        <label>Status<select name="status"><option value="pending">Pendente</option><option value="under_review">Em análise</option><option value="approved">Aprovado</option><option value="suspended">Suspenso</option></select></label>
        <label class="sx-check"><input type="checkbox" name="ships_direct_to_customer"> Despacha diretamente</label>
        <label class="sx-check"><input type="checkbox" name="discreet_outer_packaging"> Embalagem externa discreta</label>
        <div class="sx-full sx-form-actions"><button class="btn primary" type="submit">Cadastrar fornecedor</button></div>
      </form>
      ${table(["Fornecedor","Status","Despacho direto"],(data.suppliers||[]).map(s=>[`<strong>${esc(s.trade_name)}</strong><small>${esc(s.contact_email||s.contact_phone||"Sem contato")}</small>`,esc(s.status),s.ships_direct_to_customer?"Sim":"Não"]))}`;
  }
  function renderOffers(){
    return `<div class="sx-heading"><div class="sx-eyebrow">Disponibilidade do parceiro</div><h3>Ofertas</h3></div>
      <form class="sx-form sx-admin-form" data-form="offer">
        <label>Produto<select name="product_id" required>${(data.products||[]).map(p=>`<option value="${esc(p.id)}">${esc(p.name)}</option>`).join("")}</select></label>
        <label>Fornecedor<select name="supplier_id" required>${(data.suppliers||[]).map(s=>`<option value="${esc(s.id)}">${esc(s.trade_name)}</option>`).join("")}</select></label>
        <label>Preço ao cliente<input name="customer_price" type="number" min="0" step="0.01" required></label>
        <label>Moeda<select name="currency_code"><option>UYU</option><option>BRL</option><option>USD</option><option>EUR</option></select></label>
        <label>Disponibilidade<select name="availability_status"><option value="in_stock">Disponível / pronta entrega</option><option value="low_stock">Estoque baixo no fornecedor</option><option value="unknown">A confirmar</option><option value="temporarily_unavailable">Temporariamente indisponível</option><option value="out_of_stock">Indisponível</option></select></label>
        <label class="sx-check"><input type="checkbox" name="ready_to_ship"> Pronta entrega confirmada pelo fornecedor</label>
        <label class="sx-check"><input type="checkbox" name="direct_fulfillment_available"> Despacho direto ao cliente</label>
        <p class="sx-full sx-inline-note">A confirmação será registrada por 24 horas; depois disso, a disponibilidade deve ser consultada novamente.</p>
        <div class="sx-full sx-form-actions"><button class="btn primary" type="submit">Registrar oferta</button></div>
      </form>
      ${table(["Produto / Fornecedor","Disponibilidade","Preço","Validade"],(data.offers||[]).map(o=>{const p=data.products.find(x=>x.id===o.product_id),s=data.suppliers.find(x=>x.id===o.supplier_id);return [`<strong>${esc(p?.name||"Produto")}</strong><small>${esc(s?.trade_name||"Fornecedor")}</small>`,`${esc(o.availability_status)}${o.ready_to_ship?" · pronta entrega":""}`,money(o.customer_price,o.currency_code||"USD"),fmtDate(o.valid_until)];}))}`;
  }
  function renderOrders(){
    return `<div class="sx-heading"><div class="sx-eyebrow">Acompanhamento comercial</div><h3>Pedidos</h3></div>
      ${table(["Pedido / Cliente","Status","Total","Atualizar"],(data.orders||[]).map(o=>[`<strong>${esc(o.order_code)}</strong><small>${esc(o.customer_name)} · ${esc(o.customer_email)}</small>`,esc(labels[o.status]||o.status),money(o.order_total,o.currency_code||"USD"),`<select class="sx-status-select" data-order-status="${esc(o.id)}">${Object.entries(labels).map(([v,l])=>`<option value="${v}" ${o.status===v?"selected":""}>${l}</option>`).join("")}</select><button class="sx-mini" type="button" data-action="save-status" data-id="${esc(o.id)}">Salvar</button>`]))}
      <p class="sx-inline-note">Pedidos só devem ser criados após confirmação do parceiro e aprovação da cotação pelo cliente.</p>`;
  }
  function renderCustomers(){
    return `<div class="sx-heading"><div class="sx-eyebrow">Base de relacionamento</div><h3>Clientes</h3></div>
      ${table(["Cliente","Contato","Cadastro"],(data.customers||[]).map(c=>[`<strong>${esc(c.full_name||"Nome não informado")}</strong>`,`${esc(c.email||"")}<small>${esc(c.phone||"")}</small>`,fmtDate(c.created_at)]))}`;
  }
  function table(headers,rows){
    return `<div class="sx-table-wrap"><table class="sx-table"><thead><tr>${headers.map(h=>`<th>${h}</th>`).join("")}</tr></thead><tbody>${rows.length?rows.map(row=>`<tr>${row.map(cell=>`<td>${cell}</td>`).join("")}</tr>`).join(""):`<tr><td colspan="${headers.length}">Nenhum registro encontrado.</td></tr>`}</tbody></table></div>`;
  }
  function renderAdminTab(){
    const main=$("#sxAdminMain");if(!main)return;
    $("#sxPanelBody").querySelectorAll("[data-admin-tab]").forEach(b=>b.classList.toggle("is-active",b.dataset.adminTab===adminTab));
    const render={overview:adminOverview,products:renderProducts,suppliers:renderSuppliers,offers:renderOffers,orders:renderOrders,customers:renderCustomers};
    main.innerHTML=render[adminTab]();
    main.querySelectorAll("form[data-form]").forEach(f=>f.addEventListener("submit",saveAdminForm));
  }
  async function saveAdminForm(e){
    e.preventDefault();const f=e.currentTarget,fd=new FormData(f),kind=f.dataset.form,submit=f.querySelector('button[type="submit"]');submit.disabled=true;
    try{
      let result;
      if(kind==="product"){
        const name=String(fd.get("name")||"").trim();
        const row={name,slug:slug(name),category:String(fd.get("category")),short_description:String(fd.get("short_description")||"").trim()||null,description:String(fd.get("description")||"").trim()||null,image_url:String(fd.get("image_url")||"").trim()||null,age_restricted:true,is_published:fd.get("is_published")==="on",updated_at:new Date().toISOString()};
        result=fd.get("id")?await sb.from("products").update(row).eq("id",String(fd.get("id"))):await sb.from("products").insert(row);
        if(!result.error)editingId=null;
      }else if(kind==="supplier"){
        result=await sb.from("suppliers").insert({trade_name:String(fd.get("trade_name")||"").trim(),contact_name:String(fd.get("contact_name")||"").trim()||null,contact_email:String(fd.get("contact_email")||"").trim()||null,contact_phone:String(fd.get("contact_phone")||"").trim()||null,status:String(fd.get("status")),ships_direct_to_customer:fd.get("ships_direct_to_customer")==="on",discreet_outer_packaging:fd.get("discreet_outer_packaging")==="on"});
      }else if(kind==="offer"){
        const now=new Date();
        result=await sb.from("supplier_offers").insert({product_id:String(fd.get("product_id")),supplier_id:String(fd.get("supplier_id")),customer_price:Number(fd.get("customer_price")),currency_code:String(fd.get("currency_code")),availability_status:String(fd.get("availability_status")),ready_to_ship:fd.get("ready_to_ship")==="on",direct_fulfillment_available:fd.get("direct_fulfillment_available")==="on",checked_at:now.toISOString(),valid_until:new Date(now.getTime()+86400000).toISOString(),is_active:true});
      }
      if(result?.error)throw result.error;
      await loadAdmin();renderAdminTab();
      if(kind==="offer")window.alert("Oferta registrada. A confirmação vence em 24 horas.");
    }catch(err){window.alert("Não foi possível salvar: "+(err.message||"erro inesperado"));}
    finally{if(submit.isConnected)submit.disabled=false;}
  }
  async function handleAction(action,id){
    if(action==="edit-product"){editingId=id;adminTab="products";renderAdminTab();}
    if(action==="cancel-edit"){editingId=null;renderAdminTab();}
    if(action==="save-status"){
      const select=$(`[data-order-status="${CSS.escape(id)}"]`);if(!select)return;
      const status=select.value,order=(data.orders||[]).find(o=>o.id===id);
      const {error}=await sb.from("orders").update({status,updated_at:new Date().toISOString()}).eq("id",id);
      if(error)return window.alert("Não foi possível atualizar: "+error.message);
      const event=await sb.from("order_events").insert({order_id:id,event_type:"status_changed",description:"Status atualizado para: "+(labels[status]||status),customer_visible:true,actor_user_id:session.user.id});
      await loadAdmin();renderAdminTab();
      if(event.error)window.alert("Status atualizado, mas o histórico não foi salvo: "+event.error.message);
      else if(order)window.alert("Pedido "+order.order_code+" atualizado.");
    }
  }
  async function loadCatalog(){
    if(!sb||!Array.isArray(window.catalog))return;
    const {data:rows,error}=await sb.from("products").select("id,name,category,short_description,image_url").eq("is_published",true).eq("age_restricted",true);
    if(error||!rows?.length)return;
    window.catalog.splice(0,window.catalog.length,...rows.map((p,i)=>({id:1000+i,dbId:p.id,name:p.name,category:p.category,icon:p.category==="lingerie"?"♡":"✧"})));
    if(typeof window.renderProducts==="function")window.renderProducts();
  }
  async function start(){
    updateButton();if(!ready){console.warn("SensuaMix: runtime Supabase config not found.");return;}
    await syncSession();await loadCatalog();
    sb.auth.onAuthStateChange((_event,next)=>{session=next;updateButton();});
  }
  start();
})();